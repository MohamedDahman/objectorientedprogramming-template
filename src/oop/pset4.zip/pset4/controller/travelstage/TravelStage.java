package oop.pset4.controller.travelstage;

import oop.pset4.model.Luggage;

public interface TravelStage {

    Luggage process(Luggage luggage);

}
