package oop.pset4.view;

public class Host {
    public void welcome() {
        System.out.println("---------Welcome to Our Airport---------");

    }
}
